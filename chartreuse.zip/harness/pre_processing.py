import pandas as pd
import numpy as np
import argparse

def missing_value_imputation_raw_fatures(df, imputation_table, cols_to_impute):
    # Making a copy
    df_copy = df.copy()
    # Converting features to numeric values
    for c in df.columns:
        if c in cols_to_impute: df[c] = pd.to_numeric(df[c], errors="coerce")

    drop_cols = ["Unnamed: 0", "eqty_corp_family_tot", "days_rec", "roe", "HQ_city"]

    # HQ_city column's null values are filled with na
    df_copy['HQ_city'] = df_copy['HQ_city'].fillna(-1)
    
    # Columns in different categories to be imputed
    debt_impute_cols = ["debt_bank_st", "debt_bank_lt", "debt_fin_st", "debt_fin_lt", "AP_st", "AP_lt", "debt_st", "debt_lt"]
    asset_impute_cols = ['asst_intang_fixed','asst_tang_fixed','asst_fixed_fin','asst_current','AR','cash_and_equiv','goodwill']
    income_statement_impute_cols = ["rev_operating", "COGS", "prof_operations", "inc_financing", "exp_financing", "prof_financing", "inc_extraord", "taxes", "profit"]

    # Flag if certain features are missing
    # Since we are imputing in these rows, we want our model to know that there has been imputation here
    df_copy['debt_cols_imputation_flag'] = df_copy[debt_impute_cols].isna().any(axis=1).astype(int)
    df_copy['asset_cols_imputation_flag'] = df_copy[asset_impute_cols].isna().any(axis=1).astype(int)
    df_copy['income_statement_cols_imputation_flag'] = df_copy[income_statement_impute_cols].isna().any(axis=1).astype(int)

    # Reconstruction of features if null, based on formula
    df_copy["rev_operating"] = df_copy["rev_operating"].fillna(df_copy["prof_operations"] + df_copy["COGS"])
    df_copy["COGS"] = df_copy["COGS"].fillna(df_copy["rev_operating"] - df_copy["prof_operations"])
    df_copy["prof_operations"] = df_copy["prof_operations"].fillna(df_copy["rev_operating"] - df_copy["COGS"])
    df_copy["margin_fin"] = df_copy["margin_fin"].fillna(df_copy["eqty_tot"] - (df_copy["asst_intang_fixed"] + df_copy["asst_tang_fixed"] + df_copy["asst_fixed_fin"]))
    df_copy["wc_net"] = df_copy["wc_net"].fillna(df_copy["asst_current"] - df_copy["debt_st"])
    df_copy["roa"] = df_copy["roa"].fillna(df_copy["prof_operations"] / df_copy["asst_tot"] * 100)
    
    # Any reason for not including debt_st, debt_lt reconstruction?

    # In case formula imputation does not work -> impute using imputation table based on ateco_sector -> if absent, then impute the global value
    """
        LOGIC:
            if ateco_sector and asst_tot is preset in df_copy:
                df_copy[feature] = table[ateco_sector][feature] * df_copy[asst_tot]
            elif asst_tot is not preset but ateco_sector is:
                df_copy[feature] = table[ateco_sector][feature] * table[ateco_sector][asst_tot]
            elif ateco_sector is present but asst_tot is not:
                df_copy[feature] = table[global][feature] * df_copy[asst_tot]
            else both missing:
                df_copy[feature] = table[global][feature] * table[global][asst_tot]
    """
    imputation_table = imputation_table.set_index("ateco_sector")

    row_medians = imputation_table.reindex(df_copy["ateco_sector"]).set_axis(df_copy.index)
    row_medians = row_medians.fillna(imputation_table.loc["global"])
    assets = df_copy["asst_tot"].fillna(row_medians["asst_tot"])

    df_copy[cols_to_impute] = df_copy[cols_to_impute].fillna(row_medians[cols_to_impute].mul(assets, axis=0))

    return df_copy

def missing_value_imputation_crafted_features(df, imputation_table, cols_to_impute, asset_col='asst_tot'):
    df_copy = df.copy()
    for c in df.columns:
        if c in cols_to_impute: df[c] = pd.to_numeric(df[c], errors="coerce")

    # Create missingness flags before imputation
    flag_cols = {col: f"{col}_imputed_flag" for col in cols_to_impute}
    for col, flag_col in flag_cols.items(): df_copy[flag_col] = df_copy[col].isna().astype(int)

    imputation_table = imputation_table.set_index("ateco_sector")

    row_medians = imputation_table.reindex(df_copy["ateco_sector"]).set_axis(df_copy.index)
    row_medians = row_medians.fillna(imputation_table.loc["global"])
    assets = df_copy[asset_col].fillna(row_medians[asset_col])

    df_copy[cols_to_impute] = df_copy[cols_to_impute].fillna(row_medians[cols_to_impute].mul(assets, axis=0))

    return df_copy