import argparse
import pandas as pd
import numpy as np
from utils import *
from pre_processing import *
from feature_eng import *
import statsmodels.api as sm


def main():
    # Getting 
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_csv")
    parser.add_argument("--output_csv")
    args = parser.parse_args()

    df = pd.read_csv(args.input_csv)

    # Columns to impute
    debt_impute_cols = ["debt_bank_st", "debt_bank_lt", "debt_fin_st", "debt_fin_lt","AP_st", "AP_lt", "debt_st", "debt_lt"]
    asset_impute_cols = ["asst_intang_fixed", "asst_tang_fixed", "asst_fixed_fin","asst_current", "AR", "cash_and_equiv", "goodwill"]
    income_statement_impute_cols = ["rev_operating", "COGS", "prof_operations", "inc_financing","exp_financing", "prof_financing", "inc_extraord", "taxes", "profit"]

    # Final master column impute
    cols_to_impute = [*asset_impute_cols, "eqty_tot", "liab_lt", "liab_lt_emp",*debt_impute_cols, *income_statement_impute_cols, "ebitda","cf_operations"]

    # Loading Imputer Table
    imp_table = pd.read_csv("imputer.csv")
    df = missing_value_imputation_raw_fatures(df, imp_table, cols_to_impute)

    # Building Features
    flag_cols_to_keep = [c for c in df.columns if "flag" in c]
    features, feature_dict_train = build_features(df, flag_cols_to_keep)

    # Final Selected Features
    sel_features = [
        "operating_cashflow_to_liabilities",
        "operating_cashflow_to_assets",
        "cash_flow_to_debt",
        "interest_coverage_proxy",
        "debt_to_ebitda",
        "receivables_to_assets",
        "net_loss_flag",
        "operating_loss_flag",
        "nonpositive_ebitda_flag",
        "negative_equity_flag",
        "cash_to_debt_st",
        "current_assets_to_debt_st",
        "working_capital_to_assets",
        "net_profit_to_assets",
        "ebitda_to_assets",
        "operating_margin",
        "equity_to_assets",
        "debt_st_to_assets"
    ]

    # Imputing Feature Values
    feature_imputer = pd.read_csv("feature_imputer.csv")
    feature_cols_to_impute = [
        "cash_to_debt_st",
        "debt_to_ebitda",
        "interest_coverage_proxy",
        "operating_margin",
        "operating_cashflow_to_liabilities",
        "current_assets_to_debt_st",
        "cash_flow_to_debt"
    ]
    features = missing_value_imputation_crafted_features(features, feature_imputer, feature_cols_to_impute, asset_col="log_assets")

    # Prepping for prediction
    identifier_cols = ["id", "stmt_date", "ateco_sector"]
    features = features[identifier_cols + sel_features]

    # Loading Saved Model
    model = np.load("logit_parameters.npz", allow_pickle=True)
    params = pd.Series(model["params"], index=model["feature_names"])
    
    # Predicting using model
    X_predict = sm.add_constant(features[sel_features].astype(float),has_constant="add")
    X_predict = X_predict.loc[:, params.index]
    linear_score = X_predict @ params
    pd_values = 1 / (1 + np.exp(-linear_score))

    # CSV file generation
    pd_values.to_csv(args.output_csv, index=False, header=False)


if __name__ == "__main__":
    main()