# Team Chartreuse Harness Test Submission - 1
## Files
1. feature_eng.py - Contains function "build_features" for crafting ratios/features.
2. feature_imputer.csv - Contains pre-computed median of crafted feature values based on ateco sector
3. harness.py - Main harness file for prediction
4. imputer.csv - Contains pre-computed median of raw feature values based on ateco sector
5. logit_parameters.npz - Saved model parameters
6. output.csv - Output file for writing probability predictions
7. pre_processing.py - Contains functions for raw and crafted feature's imputation
8. utils.py - Contains general helper functions
9. requirements.txt - Contains all libraries and packages needed to be installed 

Note - 

1. The version numbers for packages/libraries mentioned in requirements.txt might not be a problem for execution. Please run the code once with whatever versions for the packages you have, if the code does not run, please install the mentioned versions and try again. Thanks!

2. Based on our understanding of the instructions for output file, we are passing the output csv file name (empty csv file already present in folder) as an argument while executing harness.py through terminal, and not creating it while executing.
